//
//  QuestionBank.swift
//  WeirdMaths
//
//  Created by Clary Pollack on 4/17/18.
//  Copyright © 2018 Clary Pollack. All rights reserved.
//

import Foundation

class QuestionBank{
    var list = [Question]()
    
    init() {
        list.append(Question(image: "einstein", questionText: "E = mc2", choiceA: "A. Pythagorean Theorem", choiceB: "B. Mass-Energy Equivalence", answer: 2))
        
        list.append(Question(image: "pi", questionText: "Hmmm...", choiceA: "A. 3.14", choiceB: "B. I don't get this.", answer: 1))
        
        list.append(Question(image: "square", questionText: "Associations...", choiceA: "A. Vine", choiceB: "B. Root.", answer: 2))
        
        list.append(Question(image: "equal", questionText: "Select the best answer.", choiceA: "A. =", choiceB: "B. +", answer: 1))
        
        list.append(Question(image: "pythagorean", questionText: "This is best described as:", choiceA: "A. Triangle", choiceB: "B. Pythagorean Theorem", answer: 2))
    }
}
