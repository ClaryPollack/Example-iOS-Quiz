//
//  Question.swift
//  WeirdMaths
//
//  Created by Clary Pollack on 4/17/18.
//  Copyright © 2018 Clary Pollack. All rights reserved.
//

import Foundation

class Question {
    let questionImage: String
    let question: String
    let optionA: String
    let optionB: String
    let correctAnswer: Int
    
    init(image: String, questionText: String, choiceA: String, choiceB: String, answer: Int){
        questionImage = image
        question = questionText
        optionA = choiceA
        optionB = choiceB
        correctAnswer = answer
    }
}
